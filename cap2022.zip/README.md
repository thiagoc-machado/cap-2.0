# cap2022

This application takes the database of the Spanish Ministry of Transport 
https://www.mitma.gob.es/areas-de-actividad/transporte-terrestre/servicios-al-transportista/cap/examenes-de-formacion-de-conductores-profesionales-cap
filters the data, breaks it into blocks and presents it to the user in a quiz format.
